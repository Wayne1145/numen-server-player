package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.agent.tool.NumenTool;
import com.dwinovo.numen.agent.tool.ToolRegistry;
import com.dwinovo.numen.entity.CompanionRegistry.Entry;
import com.dwinovo.numen.task.TaskResult;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

/**
 * Client-to-server payload: "the LLM running on my client side decided to
 * call this tool — please execute it on my entity".
 *
 * <h2>Trust model</h2>
 * The server treats this as unvalidated input. Validation chain:
 * <ol>
 *   <li>Target must be an {@link com.dwinovo.numen.entity.NumenPlayer} (searched across ALL
 *       dimensions — a working companion may be in the Nether while the owner
 *       waits in the overworld).</li>
 *   <li>Sender must be the entity's owner (UUID comparison, cross-dimension safe).</li>
 *   <li>Tool name must resolve to a registered {@link NumenTool}.</li>
 *   <li>Arguments JSON must parse and pass the tool's
 *       {@code toTaskRecord} validation.</li>
 * </ol>
 * There is deliberately NO owner-distance check: the whole point of the
 * chunk-ticket system is that the companion keeps working far away, and the
 * tools act at the <em>entity's</em> location with the entity's own abilities
 * — owner distance grants nothing exploitable. (Ownership is the auth.)
 *
 * <p>Any failure path emits an immediate
 * {@link TaskResultPayload} with {@code success:false} back to the sender so
 * the client agent loop can keep the conversation consistent — silently
 * dropping a tool call would leave the LLM waiting forever and the chain
 * stuck.
 *
 * <h2>Query fast path</h2>
 * Read-only perception tools never touch the
 * {@code TaskQueue} — they execute synchronously right here on the tick
 * thread and the result ships back in the same tick. Queueing them behind a
 * running {@code move_to} would turn "what's my HP" into a minute-long wait.
 *
 * <h2>Wire format</h2>
 * Fixed-shape strings (ResourceLocation for compactness on the tool name even
 * though tools live under a single namespace; this is forward-compatible for
 * multi-namespace tool registries). The arguments arrive as the raw JSON
 * string the LLM emitted; server parses with Gson and re-validates.
 */
public record ExecuteToolPayload(UUID entityUuid,
                                  String toolCallId,
                                  String toolName,
                                  String argumentsJson) implements NumenPayload {

    public static final int MAX_TOOL_CALL_ID_LENGTH = 128;
    public static final int MAX_TOOL_NAME_LENGTH = 128;
    public static final int MAX_ARGUMENTS_JSON_LENGTH = 16 * 1024;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "execute_tool");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10788(toolCallId, MAX_TOOL_CALL_ID_LENGTH);
        buf.method_10788(toolName, MAX_TOOL_NAME_LENGTH);
        buf.method_10788(argumentsJson, MAX_ARGUMENTS_JSON_LENGTH);
    }

    public static ExecuteToolPayload read(class_2540 buf) {
        return new ExecuteToolPayload(buf.method_10790(),
                buf.method_10800(MAX_TOOL_CALL_ID_LENGTH),
                buf.method_10800(MAX_TOOL_NAME_LENGTH),
                buf.method_10800(MAX_ARGUMENTS_JSON_LENGTH));
    }

    /** Handler invoked on the server main thread. */
    public static void handle(ExecuteToolPayload p, class_3222 player) {
        String who = player.method_5477().getString();
        Constants.LOG.debug("[numen-net] ← execute_tool from {} entity={} tool={} id={} args_chars={}",
                who, p.entityUuid(), p.toolName(), p.toolCallId(), p.argumentsJson().length());

        // -- 0. companion player body (the new architecture). Resolve it (or
        //       respawn it from the registry on a cold start) and run the tool
        //       through the CompanionTickDispatcher instead of the Mob GoalSelector.
        var server = player.method_37908().method_8503();
        com.dwinovo.numen.entity.NumenPlayer companion =
                com.dwinovo.numen.entity.NumenPlayer.findByUuid(server, p.entityUuid());
        if (companion == null) {
            var entry = com.dwinovo.numen.entity.CompanionRegistry.get(server).find(p.entityUuid());
            if (entry == null || !player.method_5667().equals(entry.owner())) {
                replyError(player, p, "not the owner or missing companion");
                return;
            }
            companion = com.dwinovo.numen.entity.Companions.respawn(server, p.entityUuid());
        }
        if (companion != null) {
            handleCompanion(p, player, companion);
            return;
        }
        replyError(player, p, "companion not found (never summoned, or its data is gone)");
    }

    /**
     * Run a tool against the companion player body: owner-check, then enqueue
     * world-action tools onto its queue for the {@code CompanionTickDispatcher}.
     * Query/perception tools aren't ported to the player body yet (Phase 0 wires
     * move_to + auto_mine), so they reply with a clear not-yet message.
     */
    private static void handleCompanion(ExecuteToolPayload p, class_3222 player,
                                        com.dwinovo.numen.entity.NumenPlayer companion) {
        if (!companion.isOwnedByPlayer(player.method_5667())) {
            replyError(player, p, "not the owner");
            return;
        }
        NumenTool tool = ToolRegistry.get(p.toolName());
        if (tool == null) {
            replyError(player, p, "unknown tool: " + p.toolName());
            return;
        }
        JsonObject args;
        try {
            args = JsonParser.parseString(p.argumentsJson()).getAsJsonObject();
        } catch (RuntimeException ex) {
            replyError(player, p, "invalid arguments JSON: " + ex.getMessage());
            return;
        }
        // Run the tool against the live companion: a query replies now, a world action
        // enqueues/dispatches and its result returns via the task lifecycle.
        // onServerCall 是 NumenTool 的接口默认方法——非身体工具的默认实现
        // 兜底出一条清晰失败,这里无需再分岔。
        java.util.function.Consumer<String> reply = json ->
                com.dwinovo.numen.platform.Services.NETWORK.sendToPlayer(player,
                        new TaskResultPayload(p.entityUuid(), p.toolCallId(), json));
        try {
            tool.onServerCall(p.toolCallId(), args, companion, reply);
        } catch (RuntimeException ex) {
            replyError(player, p, "invalid arguments: " + ex.getMessage());
        }
    }

    public static void replyError(class_3222 player, ExecuteToolPayload p, String message) {
        Constants.LOG.warn("[numen-net] ✗ execute_tool rejected from {}: tool={} id={} reason={}",
                player.method_5477().getString(), p.toolName(), p.toolCallId(), message);
        String json = TaskResult.fail(message).toJson();
        com.dwinovo.numen.platform.Services.NETWORK.sendToPlayer(player,
                new TaskResultPayload(p.entityUuid(), p.toolCallId(), json));
    }
}
