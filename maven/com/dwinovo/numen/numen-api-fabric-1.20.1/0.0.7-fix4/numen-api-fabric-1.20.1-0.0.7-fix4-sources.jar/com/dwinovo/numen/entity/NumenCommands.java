package com.dwinovo.numen.entity;

import com.dwinovo.numen.network.payload.ClientUiActionPayload;
import com.dwinovo.numen.platform.Services;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2277;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * The unified server-side {@code /numen} command tree — one root with
 * per-companion verbs. Lives entirely on the server so it never collides with
 * the client command dispatcher; the two inherently client-local verbs
 * ({@code settings}, {@code reset}) act on the caller's own client by firing a
 * {@link ClientUiActionPayload} back at them.
 *
 * <pre>
 *   /numen player summon &lt;name&gt;    summon the named companion (idempotent — reuses an existing one)
 *   /numen player despawn &lt;name&gt;   permanently dismiss the named companion (gone for good)
 *   /numen settings                  open the settings GUI on the caller's client
 *   /numen reset                     clear the caller's conversation loops
 * </pre>
 */
@com.dwinovo.numen.api.Internal
public final class NumenCommands {

    private NumenCommands() {}

    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(class_2170.method_9247("numen")
                .then(class_2170.method_9247("player")
                        .then(class_2170.method_9247("summon")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> summon(ctx, StringArgumentType.getString(ctx, "name")))))
                        .then(class_2170.method_9247("despawn")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> despawn(ctx, StringArgumentType.getString(ctx, "name"))))))
                .then(class_2170.method_9247("settings")
                        .executes(ctx -> clientAction(ctx, ClientUiActionPayload.Action.OPEN_SETTINGS)))
                .then(class_2170.method_9247("reset")
                        .executes(ctx -> clientAction(ctx, ClientUiActionPayload.Action.RESET_LOOPS)))
                // Pure server-side (no human owner, no client): summon/despawn/list/status a
                // SERVER-OWNED companion straight from the dedicated-server console. Ops only.
                .then(class_2170.method_9247("server")
                        .requires(src -> src.method_9259(2))
                        .then(class_2170.method_9247("summon")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> serverSummon(ctx,
                                                StringArgumentType.getString(ctx, "name"), null))
                                        .then(class_2170.method_9244("pos", class_2277.method_9737())
                                                .executes(ctx -> serverSummon(ctx,
                                                        StringArgumentType.getString(ctx, "name"),
                                                        class_2277.method_9736(ctx, "pos"))))))
                        .then(class_2170.method_9247("despawn")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> serverDespawn(ctx,
                                                StringArgumentType.getString(ctx, "name")))))
                        .then(class_2170.method_9247("list")
                                .executes(NumenCommands::serverList))
                        .then(class_2170.method_9247("status")
                                .then(class_2170.method_9244("name", StringArgumentType.word())
                                        .executes(ctx -> serverStatus(ctx,
                                                StringArgumentType.getString(ctx, "name")))))));
    }

    // ---- server-owned companion admin (console-capable; no player required) ----

    private static int serverSummon(CommandContext<class_2168> ctx, String name, class_243 posArg) {
        class_2168 src = ctx.getSource();
        MinecraftServer server = src.method_9211();
        class_3218 level = src.method_9225();               // console → overworld
        class_243 pos = posArg != null ? posArg
                : (src.method_9228() != null ? src.method_9228().method_19538()
                : class_243.method_24955(level.method_43126()));
        NumenPlayer body = Companions.summonServerOwned(server, name, level, pos);
        class_243 at = body.method_19538();
        src.method_9226(() -> class_2561.method_43470(String.format(
                "Summoned server companion '%s' (%s) at %.1f %.1f %.1f in %s",
                name, body.method_5667(), at.field_1352, at.field_1351, at.field_1350, level.method_27983().method_29177())), true);
        return 1;
    }

    private static int serverDespawn(CommandContext<class_2168> ctx, String name) {
        class_2168 src = ctx.getSource();
        int n = Companions.dismissByName(src.method_9211(), ServerOwner.ID, name);
        if (n == 0) {
            src.method_9213(class_2561.method_43470("No server companion named '" + name + "'"));
            return 0;
        }
        src.method_9226(() -> class_2561.method_43470("Dismissed server companion '" + name + "' — gone for good"
                + (n > 1 ? " (cleaned up " + n + " duplicates)" : "")), true);
        return n;
    }

    private static int serverList(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        MinecraftServer server = src.method_9211();
        List<Map.Entry<UUID, CompanionRegistry.Entry>> entries = new ArrayList<>();
        for (Map.Entry<UUID, CompanionRegistry.Entry> e :
                CompanionRegistry.get(server).ownedBy(ServerOwner.ID)) {
            entries.add(e);
        }
        if (entries.isEmpty()) {
            src.method_9226(() -> class_2561.method_43470("No server companions."), false);
            return 0;
        }
        src.method_9226(() -> class_2561.method_43470("Server companions (" + entries.size() + "):"), false);
        for (Map.Entry<UUID, CompanionRegistry.Entry> e : entries) {
            CompanionRegistry.Entry ent = e.getValue();
            NumenPlayer live = NumenPlayer.findByUuid(server, e.getKey());
            String state = live != null ? (live.isDegraded() ? "DEGRADED" : "live")
                    : (ent.diedAt() > 0L ? "dead" : "dormant");
            String hp = live != null
                    ? String.format("  hp=%.0f/%.0f", live.method_6032(), live.method_6063()) : "";
            String line = String.format("  - %s  [%s]  %s @ %s%s  %s",
                    ent.name(), state, ent.pos().method_23854(), ent.dimension().method_29177(), hp, e.getKey());
            src.method_9226(() -> class_2561.method_43470(line), false);
        }
        return entries.size();
    }

    private static int serverStatus(CommandContext<class_2168> ctx, String name) {
        class_2168 src = ctx.getSource();
        MinecraftServer server = src.method_9211();
        UUID id = null;
        CompanionRegistry.Entry ent = null;
        for (Map.Entry<UUID, CompanionRegistry.Entry> e :
                CompanionRegistry.get(server).ownedBy(ServerOwner.ID)) {
            if (e.getValue().name().equals(name)) {
                id = e.getKey();
                ent = e.getValue();
                break;
            }
        }
        if (ent == null) {
            src.method_9213(class_2561.method_43470("No server companion named '" + name + "'"));
            return 0;
        }
        NumenPlayer live = NumenPlayer.findByUuid(server, id);
        StringBuilder sb = new StringBuilder();
        sb.append("Companion '").append(name).append("' ").append(id);
        if (live != null) {
            sb.append("\n  state: ").append(live.isDegraded() ? "DEGRADED" : "live");
            sb.append("\n  pos: ").append(live.method_24515().method_23854())
                    .append(" @ ").append(live.method_37908().method_27983().method_29177());
            sb.append("\n  hp: ").append(String.format("%.1f/%.1f", live.method_6032(), live.method_6063()));
            sb.append("\n  food: ").append(live.method_7344().method_7586()).append("/20");
            if (live.isDegraded()) {
                sb.append("\n  lastError: ").append(live.lastTickError());
            }
        } else {
            sb.append("\n  state: ").append(ent.diedAt() > 0L ? "dead (awaiting respawn)" : "dormant");
            sb.append("\n  lastPos: ").append(ent.pos().method_23854())
                    .append(" @ ").append(ent.dimension().method_29177());
            if (ent.diedAt() > 0L) {
                sb.append("\n  deathCause: ").append(ent.deathCause());
            }
        }
        String out = sb.toString();
        src.method_9226(() -> class_2561.method_43470(out), false);
        return 1;
    }

    private static int summon(CommandContext<class_2168> ctx, String name)
            throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        class_3218 level = (class_3218) owner.method_37908();
        NumenPlayer body = Companions.summon(
                level.method_8503(), owner.method_5667(), name, level, owner.method_19538());
        // Push the updated roster so the owner's G panel can reach the new companion.
        Companions.syncRosterToOwner(level.method_8503(), owner);
        ctx.getSource().method_9226(() ->
                class_2561.method_43470("Summoned companion '" + name + "' (" + body.method_5667() + ")"), false);
        return 1;
    }

    private static int despawn(CommandContext<class_2168> ctx, String name)
            throws CommandSyntaxException {
        class_3222 owner = ctx.getSource().method_9207();
        var server = owner.method_37908().method_8503();
        // Permanent dismissal: removes the live body AND its registry entry (and any same-name
        // duplicates), so it does NOT come back on the next login. NOT dormancy.
        int dismissed = Companions.dismissByName(server, owner.method_5667(), name);
        if (dismissed == 0) {
            ctx.getSource().method_9213(
                    class_2561.method_43470("No companion of yours named '" + name + "'"));
            return 0;
        }
        Companions.syncRosterToOwner(server, owner);
        ctx.getSource().method_9226(() -> class_2561.method_43470(
                "Dismissed companion '" + name + "' — gone for good"
                        + (dismissed > 1 ? " (cleaned up " + dismissed + " duplicates)" : "")), false);
        return dismissed;
    }

    private static int clientAction(CommandContext<class_2168> ctx,
                                    ClientUiActionPayload.Action action)
            throws CommandSyntaxException {
        class_3222 caller = ctx.getSource().method_9207();
        Services.NETWORK.sendToPlayer(caller, new ClientUiActionPayload(action));
        return 1;
    }
}
