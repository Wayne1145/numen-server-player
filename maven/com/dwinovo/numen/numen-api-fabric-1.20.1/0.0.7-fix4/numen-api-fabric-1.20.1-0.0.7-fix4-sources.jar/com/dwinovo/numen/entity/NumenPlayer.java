package com.dwinovo.numen.entity;

import com.mojang.authlib.GameProfile;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_2487;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.util.UUID;

/**
 * The companion body: a server-side fake {@link class_3222}. Replaces the old
 * custom {@code NumenEntity} Mob so the companion is a first-class player —
 * native interaction/combat code paths (universal mod compatibility), its own
 * player inventory, and free chunk loading + playerdata persistence by virtue of
 * being a list-resident player.
 *
 * <h2>Identity &amp; ownership</h2>
 * Created by {@link CompanionFactory} with a stable per-companion UUID (carried
 * in the {@link GameProfile}); the enumerable index lives in
 * {@link CompanionRegistry}. Unlike the Mob, a fake player cannot carry custom
 * {@code SynchedEntityData}, so the owner is a plain server-side field persisted
 * to the companion's own playerdata {@code .dat} via
 * {@link #method_5652}. Owner checks are UUID comparisons — never
 * vanilla {@code isOwnedBy} (which resolves through a level and breaks across
 * dimensions).
 */
public final class NumenPlayer extends class_3222 {

    private static final String NBT_KEY_OWNER = "NumenOwner";

    /** Owner's player UUID. Null only transiently before the first assignment. */
    private UUID ownerUuid;

    /** Latched once we've handled this body's death, so the post-death routine runs exactly once. */
    private boolean deathHandled;

    /** Consecutive failed ticks before a body is paused (degraded) — ~1s of solid failures. */
    private static final int TICK_DEGRADE_THRESHOLD = 20;
    /** Min ticks between logged tick errors while failing (~5s), so a broken body can't flood the log. */
    private static final long TICK_LOG_INTERVAL = 100L;

    /** Rate-limited tick-failure accounting — replaces the old silent {@code catch (Exception ignored)}. */
    private final TickWatchdog tickWatchdog = new TickWatchdog(TICK_DEGRADE_THRESHOLD, TICK_LOG_INTERVAL);

    public NumenPlayer(MinecraftServer server, class_3218 level, GameProfile profile) {
        super(server, level, profile);   // 1.20.1: no ClientInformation (pre-configuration-phase)
    }

    /**
     * 点亮全部皮肤覆盖层(帽子/夹克/左右袖/左右裤腿)与披风。假玩家没有客户端上报的
     * 模型定制,不设这个字节客户端只渲染单层基础皮肤。该字节是同步实体数据、不随 .dat
     * 存取,故每次进世界都要重设一次(经 {@code protected} 的 DATA_PLAYER_MODE_CUSTOMISATION
     * 访问,子类内可见)。
     */
    public void showAllSkinLayers() {
        method_5841().method_12778(field_7518, (byte) 0x7f);
    }

    /** The loaded companion body with this UUID, or {@code null} if not spawned. */
    public static NumenPlayer findByUuid(MinecraftServer server, UUID uuid) {
        return server.method_3760().method_14602(uuid) instanceof NumenPlayer ap ? ap : null;
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public void setOwnerUuid(UUID ownerUuid) {
        this.ownerUuid = ownerUuid;
    }

    /** Cross-dimension safe owner check — UUID comparison, not level-scoped lookup. */
    public boolean isOwnedByPlayer(UUID playerUuid) {
        return ownerUuid != null && ownerUuid.equals(playerUuid);
    }

    /** The owner as an online player, server-wide; null when offline. */
    public class_3222 resolveOwnerPlayer() {
        return ownerUuid == null ? null : method_37908().method_8503().method_3760().method_14602(ownerUuid);
    }


    /** True if {@code item} sits anywhere in the inventory (hotbar/main/offhand all count). */
    public boolean ensureInInventory(class_1792 item) {
        var inv = method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(item)) return true;
        }
        return false;
    }

    /**
     * Hold the item in inventory slot {@code slot} in the main hand the way a real player
     * does — a hotbar slot is simply SELECTED (number-key); a main-inventory slot is SWAPPED
     * into the currently selected hotbar slot (item-conserving). This is the only correct way
     * to "switch to hand": calling {@code setItemInHand(MAIN_HAND, stack)} overwrites the held
     * item (losing it) and aliases ONE {@link net.minecraft.class_1799} across two
     * slots, which corrupts the inventory once the stack is consumed. No-op for {@code slot < 0}.
     */
    public void holdInHand(int slot) {
        if (slot < 0) {
            return;
        }
        var inv = method_31548();
        if (net.minecraft.class_1661.method_7380(slot)) {
            inv.field_7545 = slot;
            return;
        }
        int selected = inv.field_7545;
        net.minecraft.class_1799 held = inv.method_5438(selected);
        inv.method_5447(selected, inv.method_5438(slot));
        inv.method_5447(slot, held);
    }

    // ---- server tick (restore the movement pass a fake connection skips) ----

    /**
     * Drive the body's own movement physics. A real {@link class_3222} runs
     * {@code travel} (against {@code zza}/{@code xxa}), food, air and pose inside
     * {@link #method_14226()}, which the network layer invokes via
     * {@code connection.tick()}. A fake player's connection is a no-op, so
     * {@code doTick()} never fires and the body would only ever turn (a direct
     * {@code setYRot} write) without walking. The entity system already calls
     * {@code super.tick()} (menus / container / position sync), so we add the
     * missing {@code doTick()} movement pass here in our own {@code tick()}
     * override. Every 10 ticks we resync the
     * connection position and let chunk loading follow the body so it never
     * walks out of its loaded area.
     */
    @Override
    public void method_5773() {
        // A fake player isn't auto-removed on death (no client to send a respawn packet), so it would
        // sit at 0 HP forever. Detect death once, hand off to the recoverable-death routine (stop the
        // brain, schedule a respawn at the owner), and skip the normal movement/AI tick for this corpse.
        if (!deathHandled && (method_6032() <= 0.0f || method_29504())) {
            deathHandled = true;
            Companions.onDeath(this);
            return;
        }
        if (method_37908() instanceof class_3218 sl && sl.method_8510() % 10 == 0) {
            this.field_13987.method_14372();
            sl.method_14178().method_14096(this);
        }
        super.method_5773();
        // A degraded body is PAUSED: it stays in-world (list-resident, persisted) but skips its
        // movement pass here and its tasks (see CompanionTickDispatcher.tick) so one broken
        // companion can neither flood the log nor wedge the server.
        if (tickWatchdog.isDegraded()) {
            return;
        }
        // Restore the movement pass a fake connection skips. Unlike the old silent
        // `catch (Exception ignored)`, failures are rate-limit-logged (companion UUID + exception
        // type) and, after a run of consecutive failures, flip the body to DEGRADED (paused, tasks
        // stopped, visible to get_self_status) — never hidden, never a whole-server crash.
        try {
            this.method_14226();
            tickWatchdog.recordSuccess();
        } catch (Exception ex) {
            handleTickError(ex);
        }
    }

    /** Rate-limited logging + degrade-on-repeated-failure for {@link #method_5773()}'s movement pass. */
    private void handleTickError(Exception ex) {
        long tick = method_37908() instanceof class_3218 sl ? sl.method_8510() : 0L;
        String label = ex.getClass().getName() + ": " + ex.getMessage();
        TickWatchdog.Decision d = tickWatchdog.recordError(label, tick);
        if (d.shouldLog()) {
            com.dwinovo.numen.Constants.LOG.warn(
                    "[numen] companion '{}' ({}) tick error #{}: {}",
                    method_5477().getString(), method_5667(), tickWatchdog.consecutiveErrors(), label, ex);
        }
        if (d.justDegraded()) {
            com.dwinovo.numen.Constants.LOG.error(
                    "[numen] companion '{}' ({}) is DEGRADED after {} consecutive tick errors — "
                            + "pausing it and stopping its tasks",
                    method_5477().getString(), method_5667(), tickWatchdog.consecutiveErrors());
            com.dwinovo.numen.task.CompanionTickDispatcher.stopTasksForDegraded(this);
        }
    }

    /** True if this body was paused after repeated tick failures (see {@link TickWatchdog}). */
    public boolean isDegraded() {
        return tickWatchdog.isDegraded();
    }

    /** Last tick-failure description (exception type + message), or {@code ""} if none. */
    public String lastTickError() {
        return tickWatchdog.lastError();
    }

    /** Current run of consecutive failed ticks. */
    public int consecutiveTickErrors() {
        return tickWatchdog.consecutiveErrors();
    }

    /** Clear a degraded state and let the body resume (admin recovery / fresh respawn). */
    public void clearDegraded() {
        tickWatchdog.reset();
    }

    @Override
    public void method_5652(class_2487 output) {
        super.method_5652(output);
        if (ownerUuid != null) {
            output.method_25927(NBT_KEY_OWNER, ownerUuid);   // 1.21.4: no CompoundTag.store(Codec)
        }
    }

    @Override
    public void method_5749(class_2487 input) {
        super.method_5749(input);
        if (input.method_25928(NBT_KEY_OWNER)) this.ownerUuid = input.method_25926(NBT_KEY_OWNER);
    }
}
