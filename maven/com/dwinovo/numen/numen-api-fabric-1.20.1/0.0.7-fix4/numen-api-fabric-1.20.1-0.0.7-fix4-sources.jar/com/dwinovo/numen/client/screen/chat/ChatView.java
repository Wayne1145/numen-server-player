package com.dwinovo.numen.client.screen.chat;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.agent.llm.ConvoLog;
import com.dwinovo.numen.agent.llm.ConvoState;
import com.dwinovo.numen.agent.provider.AssistantTurn;
import com.dwinovo.numen.agent.provider.LlmToolCall;
import com.dwinovo.numen.client.agent.ClientNumenLookup;
import com.dwinovo.numen.client.agent.EntityAgentLoop;
import com.dwinovo.numen.client.chat.ChatDisplayFilters;
import com.dwinovo.numen.client.screen.Nb;
import com.dwinovo.numen.client.screen.UiTheme;
import com.dwinovo.numen.client.ui.Anim;
import com.dwinovo.numen.client.ui.RoundRect;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.function.Supplier;
import net.minecraft.class_1068;
import net.minecraft.class_1074;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_5481;
import net.minecraft.class_742;
import net.minecraft.class_7532;

/**
 * The chat transcript as a conversation: the owner's messages are right-aligned
 * bubbles, the companion's replies left-aligned bubbles — both with their real
 * skin avatar — and a run of consecutive tool calls folds into one rounded chip
 * (click to expand once done). System notes (persona change / compaction / empty
 * hint) sit centred and faint. Scrolling is eased ({@link Anim#approach}) and
 * pins to the bottom while the owner hasn't scrolled away.
 *
 * <p>Blocks are rebuilt every frame from the loop's PHYSICAL transcript (exactly
 * what the old flat row list read), so live tool spinners and mid-run arrivals
 * need no extra invalidation. The view owns scroll + fold state; {@code reset()}
 * on companion/tab switch.
 */
public final class ChatView {

    // ---- metrics ----
    private static final int LINE_H = 10;
    private static final int LABEL_H = 9;       // companion name line above its bubble
    private static final int AV = 18;           // avatar face size
    private static final int AV_GAP = 5;        // avatar ↔ bubble
    private static final int PAD_H = 5;         // bubble text inset
    private static final int PAD_V = 4;         // 1 line → 18px bubble = exactly the avatar height
    private static final int BLOCK_GAP = 6;
    private static final int TOP_PAD = 2;
    private static final int BOT_PAD = 2;
    private static final int SB_W = 4;          // scrollbar width
    private static final int EDGE = 2;          // left inset so the avatar FRAME (-2px) clears the scissor
    private static final int OPP_MARGIN = 24;   // kept clear on the far side of a bubble
    private static final int RADIUS = 4;
    private static final int ICON_W = 11;       // chip status-icon column
    private static final int TOOL_ARG_CHARS = 44;
    private static final float SCROLL_RATE = 14f;
    /** Typewriter reveal speed (chars/s) and the max lag before it jumps to catch up. */
    private static final float REVEAL_CPS = 80f;
    private static final int REVEAL_MAX_LAG = 120;
    private static final String[] SPIN = {"|", "/", "-", "\\"};

    // ---- palette: re-read from the CURRENT theme each frame (loadPalette), so the
    // Settings picker recolours the transcript live. Field names keep the constant
    // convention — they behave as constants within a frame. ----
    private int TOOL, MUTED, FAINT, OK, RUN, FAIL, TXT;
    private int AI_FILL, AI_BORDER, OWN_FILL, OWN_BORDER, QUEUED_FILL, QUEUED_BORDER, CHIP_FILL;

    private void loadPalette() {
        UiTheme t = UiTheme.current();
        TOOL = t.textDim();
        MUTED = t.textDim();
        FAINT = t.faint();
        OK = t.ok();
        RUN = t.run();
        FAIL = t.fail();
        TXT = t.text();
        AI_FILL = t.aiFill();
        AI_BORDER = t.aiBorder();
        OWN_FILL = t.ownFill();
        OWN_BORDER = t.ownBorder();
        QUEUED_FILL = t.queuedFill();
        QUEUED_BORDER = t.queuedBorder();
        CHIP_FILL = t.chipFill();
    }

    private static class_2960 spr(String n) {
        return new class_2960(Constants.MOD_ID, n);
    }
    private static final class_2960 AVATAR_FRAME = spr("avatar_frame");
    private static final class_2960 SCROLL_TRACK = spr("scroll_track");
    private static final class_2960 SCROLL_THUMB = spr("scroll_thumb");

    private final class_327 font;
    private final Supplier<EntityAgentLoop> loop;
    private final Supplier<String> name;
    private final Supplier<UUID> uuid;

    // ---- scroll + fold state ----
    private float scrollPos;
    private int scrollTarget;
    private boolean pinBottom = true;
    private int lastMaxScroll;
    private long lastFrameMs;
    /** Typewriter state: how much of the live partial is revealed, and the string
     *  (text + blinking caret) the current frame shows — build() reads the cache so
     *  click-time rebuilds see the same geometry. */
    private float revealed;
    private String liveShown = "";
    /** Completed tool-call groups the user clicked open (keyed by the group's first call id). */
    private final Set<String> expandedGroups = new HashSet<>();
    // geometry of the last render, for click / wheel hit-testing
    private int gx, gy, gw, gh;

    public ChatView(class_327 font, Supplier<EntityAgentLoop> loop, Supplier<String> name, Supplier<UUID> uuid) {
        this.font = font;
        this.loop = loop;
        this.name = name;
        this.uuid = uuid;
    }

    /** Forget scroll + fold state (companion or tab switch). */
    public void reset() {
        scrollPos = 0;
        scrollTarget = 0;
        pinBottom = true;
        lastFrameMs = 0;
        revealed = 0;
        liveShown = "";
        expandedGroups.clear();
    }

    /** Re-pin to the bottom (a message was just sent). */
    public void pinToBottom() {
        pinBottom = true;
    }

    // ---- render ----

    public void render(class_332 g, int x, int y, int w, int h) {
        gx = x; gy = y; gw = w; gh = h;
        loadPalette();
        long now = System.currentTimeMillis();
        float dt = lastFrameMs == 0 ? 0.016f : Math.min(0.1f, (now - lastFrameMs) / 1000f);
        lastFrameMs = now;
        updateLive(dt, now);
        List<Block> blocks = build(bubbleMaxW(w));
        int content = totalHeight(blocks);
        lastMaxScroll = Math.max(0, content - h);
        if (pinBottom) scrollTarget = lastMaxScroll;
        scrollTarget = net.minecraft.class_3532.method_15340(scrollTarget, 0, lastMaxScroll);
        scrollPos = Anim.approach(scrollPos, scrollTarget, SCROLL_RATE, dt);

        g.method_44379(x, y, x + w, y + h);
        int cy = y + TOP_PAD - Math.round(scrollPos);
        for (Block b : blocks) {
            int bh = heightOf(b);
            if (cy + bh > y && cy < y + h) drawBlock(g, b, x, cy, w);
            cy += bh + BLOCK_GAP;
        }
        g.method_44380();

        if (lastMaxScroll > 0) {
            int thumbH = Math.max(12, h * h / (h + lastMaxScroll));
            int thumbY = y + Math.round((h - thumbH) * (scrollPos / lastMaxScroll));
            com.dwinovo.numen.client.screen.GuiCompat.blitSprite(g, SCROLL_TRACK, x + w - SB_W, y, SB_W, h);
            com.dwinovo.numen.client.screen.GuiCompat.blitSprite(g, SCROLL_THUMB, x + w - SB_W, thumbY, SB_W, thumbH);
        }
    }

    /** Wheel anywhere on the chat tab scrolls the transcript (parity with the old list). */
    public boolean mouseScrolled(double sy) {
        scrollTarget = net.minecraft.class_3532.method_15340((int) (scrollTarget - sy * LINE_H * 3), 0, lastMaxScroll);
        pinBottom = scrollTarget >= lastMaxScroll;
        return true;
    }

    /** Toggle the fold of a completed tool chip under the mouse. */
    public boolean mouseClicked(double mx, double my) {
        if (gw == 0 || mx < gx || mx >= gx + gw || my < gy || my >= gy + gh) return false;
        loadPalette();
        int cy = gy + TOP_PAD - Math.round(scrollPos);
        for (Block b : build(bubbleMaxW(gw))) {
            int bh = heightOf(b);
            if (b instanceof Chip c && c.foldKey() != null && my >= cy && my < cy + bh) {
                if (!expandedGroups.add(c.foldKey())) expandedGroups.remove(c.foldKey());
                return true;
            }
            cy += bh + BLOCK_GAP;
        }
        return false;
    }

    // ---- blocks ----

    private sealed interface Block permits Bubble, Chip, Notice {}

    /** One spoken message. {@code label} non-null = companion side (name above the bubble);
     *  {@code showAvatar} false = a consecutive message from the same side (head hidden). */
    private record Bubble(boolean own, String label, List<class_5481> lines,
                          int maxLineW, int textColor, int fill, int border,
                          boolean showAvatar) implements Block {}

    /** A run of tool calls. {@code foldKey} non-null = finished group, clickable to expand/fold. */
    private record Chip(List<ChipRow> rows, String foldKey) implements Block {}

    private record ChipRow(String icon, int iconColor, class_5481 text) {}

    /** A centred, faint system note. */
    private record Notice(class_5481 text) implements Block {}

    private int bubbleMaxW(int w) {
        return w - EDGE - AV - AV_GAP - OPP_MARGIN - SB_W - 3;
    }

    private int heightOf(Block b) {
        if (b instanceof Bubble bb) {
            return (bb.label() != null ? LABEL_H : 0) + bb.lines().size() * LINE_H + PAD_V * 2;
        }
        if (b instanceof Chip c) {
            return c.rows().size() * LINE_H + PAD_V * 2;
        }
        return LINE_H;   // Notice
    }

    private int totalHeight(List<Block> blocks) {
        int sum = TOP_PAD + BOT_PAD;
        for (int i = 0; i < blocks.size(); i++) {
            sum += heightOf(blocks.get(i)) + (i > 0 ? BLOCK_GAP : 0);
        }
        return sum;
    }

    /** Flatten the loop's PHYSICAL transcript (not the LLM context — compaction must
     *  never eat the owner's visible history) into renderable blocks. */
    private List<Block> build(int bubbleMaxW) {
        List<Block> out = new ArrayList<>();
        EntityAgentLoop lp = loop.get();
        Set<String> done = new HashSet<>();
        Set<String> failed = new HashSet<>();
        for (ConvoState.Msg m : lp.display()) {
            if (m instanceof ConvoState.Msg.Tool t) {
                done.add(t.toolCallId());
                if (looksFailed(t.content())) failed.add(t.toolCallId());
            }
        }
        int innerW = bubbleMaxW - PAD_H * 2;
        List<LlmToolCall> group = new ArrayList<>();
        // Consecutive same-side messages group like a chat app: avatar + name only on
        // the first of a run. Chips don't break a run; notices do. null = run broken.
        Boolean lastSide = null;
        for (ConvoState.Msg msg : lp.display()) {
            // Java 17(1.20.1 分支):switch 模式匹配不可用,展开为 instanceof 链。
            if (msg instanceof ConvoState.Msg.User u) {
                flushTools(out, group, done, failed, bubbleMaxW);
                if (ConvoLog.PERSONA_DIVIDER.equals(u.content())) {
                    notice(out, class_1074.method_4662("numen.chat.persona_changed"));
                    lastSide = null;
                    continue;
                }
                if (ConvoLog.COMPACT_DIVIDER.equals(u.content())) {
                    notice(out, class_1074.method_4662("numen.chat.compacted"));
                    lastSide = null;
                    continue;
                }
                String shown = ownerText(u.content());   // owner's words only, never injected content
                if (shown.isEmpty()) continue;
                boolean first = lastSide == null || !lastSide;
                out.add(bubble(true, null, shown, TXT, OWN_FILL, OWN_BORDER, innerW, first));
                lastSide = true;
            } else if (msg instanceof ConvoState.Msg.Assistant a) {
                AssistantTurn turn = a.turn();
                String spoken = ChatDisplayFilters.current().filterAssistantMessage(turn.content());
                if (!spoken.isBlank()) {
                    flushTools(out, group, done, failed, bubbleMaxW);   // spoken reply breaks the fold
                    boolean first = lastSide == null || lastSide;
                    out.add(bubble(false, first ? name.get() : null, spoken,
                            TXT, AI_FILL, AI_BORDER, innerW, first));
                    lastSide = false;
                }
                group.addAll(turn.toolCalls());
            }
            // Msg.Tool: result drives done/fail, not a block
        }
        flushTools(out, group, done, failed, bubbleMaxW);
        // The in-flight reply, typed out live (chunk stream → EntityAgentLoop.livePartial).
        if (!liveShown.isEmpty()) {
            boolean first = lastSide == null || lastSide;
            out.add(bubble(false, first ? name.get() : null, liveShown,
                    TXT, AI_FILL, AI_BORDER, innerW, first));
            lastSide = false;
        }
        // Prompts still waiting for a protocol-valid splice point — visible immediately
        // so a queued message never feels swallowed.
        for (String queued : lp.queuedPrompts()) {
            String shown = ownerText(queued);
            if (shown.isEmpty()) continue;
            boolean first = lastSide == null || !lastSide;
            out.add(bubble(true, null, "⌛ " + shown, FAINT, QUEUED_FILL, QUEUED_BORDER, innerW, first));
            lastSide = true;
        }
        if (lp.isCompacting()) notice(out, class_1074.method_4662("numen.chat.compacting"));
        if (out.isEmpty()) notice(out, class_1074.method_4662("numen.chat.empty", name.get()));
        return out;
    }

    private Bubble bubble(boolean own, String label, String text, int color, int fill, int border,
                          int innerW, boolean showAvatar) {
        List<class_5481> lines = font.method_1728(Nb.colored(text, color), innerW);
        int maxW = 0;
        for (class_5481 l : lines) maxW = Math.max(maxW, font.method_30880(l));
        return new Bubble(own, label, lines, maxW, color, fill, border, showAvatar);
    }

    /** Advance the typewriter: filter the live partial, ease the reveal toward the
     *  full length, and cache "revealed text + blinking caret". */
    private void updateLive(float dt, long now) {
        String full = ChatDisplayFilters.current().filterAssistantMessage(loop.get().livePartial());
        if (full.isEmpty()) {
            revealed = 0;
            liveShown = "";
            return;
        }
        if (revealed > full.length()) revealed = full.length();
        if (full.length() - revealed > REVEAL_MAX_LAG) revealed = full.length() - REVEAL_MAX_LAG;
        revealed = Math.min(full.length(), revealed + dt * REVEAL_CPS);
        liveShown = cut(full, (int) revealed) + (((now / 500) & 1) == 0 ? "_" : "");
    }

    /** Cut at {@code n} chars without splitting a surrogate pair. */
    private static String cut(String s, int n) {
        if (n >= s.length()) return s;
        if (n > 0 && Character.isHighSurrogate(s.charAt(n - 1))) n--;
        return s.substring(0, n);
    }

    private void notice(List<Block> out, String text) {
        out.add(new Notice(Nb.colored(text, FAINT).method_30937()));
    }

    /** Emit the chip for a run of consecutive tool calls. A single call is one unfoldable chip;
     *  a run stays EXPANDED while any call still runs (live spinners) and auto-folds to a
     *  "N steps · names" summary once done — unless clicked open ({@link #expandedGroups}). */
    private void flushTools(List<Block> out, List<LlmToolCall> group,
                            Set<String> done, Set<String> failed, int chipMaxW) {
        if (group.isEmpty()) return;
        int textW = chipMaxW - PAD_H * 2 - ICON_W;
        long t = System.currentTimeMillis();
        List<ChipRow> rows = new ArrayList<>();
        String foldKey = null;
        if (group.size() == 1) {
            rows.add(toolRow(group.get(0), done, failed, t, textW));
        } else {
            String key = group.get(0).id();
            boolean running = group.stream().anyMatch(tc -> !done.contains(tc.id()));
            if (!running) foldKey = key;
            if (running || expandedGroups.contains(key)) {
                if (!running) {
                    rows.add(new ChipRow("▾", MUTED,
                            Nb.colored(class_1074.method_4662("numen.chat.steps", group.size()), MUTED).method_30937()));
                }
                for (LlmToolCall tc : group) rows.add(toolRow(tc, done, failed, t, textW));
            } else {
                List<String> names = new ArrayList<>();
                for (LlmToolCall tc : group) {
                    String label = toolLabel(tc.name());
                    if (!names.contains(label)) names.add(label);
                }
                boolean anyFail = group.stream().anyMatch(tc -> failed.contains(tc.id()));
                String summary = class_1074.method_4662("numen.chat.steps", group.size())
                        + " · " + String.join(" · ", names) + " ▸";
                rows.add(new ChipRow(anyFail ? "✗" : "✔", anyFail ? FAIL : OK,
                        Nb.colored(fitOneLine(summary, textW), anyFail ? FAIL : TOOL).method_30937()));
            }
        }
        out.add(new Chip(List.copyOf(rows), foldKey));
        group.clear();
    }

    private ChipRow toolRow(LlmToolCall tc, Set<String> done, Set<String> failed, long t, int textW) {
        boolean running = !done.contains(tc.id());
        boolean fail = failed.contains(tc.id());
        String icon = running ? SPIN[(int) ((t / 120) % 4)] : (fail ? "✗" : "✔");
        int ic = running ? RUN : (fail ? FAIL : OK);
        return new ChipRow(icon, ic,
                Nb.colored(fitOneLine(toolLine(tc), textW), fail ? FAIL : TOOL).method_30937());
    }

    // ---- drawing ----

    private void drawBlock(class_332 g, Block b, int x, int y, int w) {
        if (b instanceof Notice n) {
            int tw = font.method_30880(n.text());
            draw(g, n.text(), x + (w - SB_W - tw) / 2, y);
        } else if (b instanceof Bubble bb) {
            drawBubble(g, bb, x, y, w);
        } else if (b instanceof Chip c) {
            drawChip(g, c, x, y);
        }
    }

    private void drawBubble(class_332 g, Bubble b, int x, int y, int w) {
        int bw = b.maxLineW() + PAD_H * 2;
        int bh = b.lines().size() * LINE_H + PAD_V * 2;
        int bubTop = y + (b.label() != null ? LABEL_H : 0);
        int avX, bx;
        if (b.own()) {
            avX = x + w - SB_W - 3 - AV;
            bx = avX - AV_GAP - bw;
        } else {
            avX = x + EDGE;
            bx = x + EDGE + AV + AV_GAP;
        }
        if (b.label() != null) {
            draw(g, Nb.colored(b.label(), MUTED).method_30937(), bx + 2, y);
        }
        if (b.showAvatar()) {
            com.dwinovo.numen.client.screen.GuiCompat.blitSprite(g, AVATAR_FRAME, avX - 2, bubTop - 2, AV + 4, AV + 4);
            class_7532.method_44443(g, skin(b.own()), avX, bubTop, AV);
        }
        RoundRect.card(g, bx, bubTop, bx + bw, bubTop + bh, RADIUS, b.fill(), b.border());
        int ty = bubTop + PAD_V + 1;
        for (class_5481 l : b.lines()) {
            draw(g, l, bx + PAD_H, ty);
            ty += LINE_H;
        }
    }

    private void drawChip(class_332 g, Chip c, int x, int y) {
        int maxW = 0;
        for (ChipRow r : c.rows()) maxW = Math.max(maxW, font.method_30880(r.text()));
        int cx = x + EDGE + AV + AV_GAP;
        int cw = ICON_W + maxW + PAD_H * 2;
        int ch = c.rows().size() * LINE_H + PAD_V * 2;
        RoundRect.fill(g, cx, y, cx + cw, y + ch, RADIUS, CHIP_FILL);
        int ty = y + PAD_V + 1;
        for (ChipRow r : c.rows()) {
            draw(g, Nb.colored(r.icon(), r.iconColor()).method_30937(), cx + PAD_H, ty);
            draw(g, r.text(), cx + PAD_H + ICON_W, ty);
            ty += LINE_H;
        }
    }

    /** Shadowless draw — the colour is baked into the sequence's Style (see {@link Nb}). */
    private void draw(class_332 g, class_5481 seq, int x, int y) {
        Nb.text(g, font, seq, x, y);
    }

    /** 1.20.1:皮肤是贴图 ResourceLocation(还没有 1.20.2+ 的 PlayerSkin record)。 */
    private net.minecraft.class_2960 skin(boolean own) {
        if (own) {
            class_742 p = class_310.method_1551().field_1724;
            if (p != null) return p.method_3117();
            return class_1068.method_4648(uuid.get());
        }
        return com.dwinovo.numen.client.agent.KnownSkins.of(uuid.get());
    }

    // ---- text helpers ----

    private static String ownerText(String s) {
        return ChatDisplayFilters.current().filterUserMessage(s);
    }

    private String fitOneLine(String s, int pxWidth) {
        if (font.method_1727(s) <= pxWidth) return s;
        while (s.length() > 1 && font.method_1727(s + "…") > pxWidth) s = s.substring(0, s.length() - 1);
        return s + "…";
    }

    private static String toolLine(LlmToolCall tc) {
        String args = humanArgs(tc.arguments());
        return args.isEmpty() ? toolLabel(tc.name()) : toolLabel(tc.name()) + "  " + args;
    }

    /** 工具名 → 人话:约定键 {@code numen.tool.<name>};没有译文的(MCP 外部工具)原样显示。 */
    private static String toolLabel(String name) {
        String key = "numen.tool." + name;
        return class_1074.method_4663(key) ? class_1074.method_4662(key) : name;
    }

    /** 参数 JSON → 人读摘要:抓最能说明这一步的名词(物品/方块/目标)、坐标、数量,
     *  最多三段;拿不出名词或解析不了就回落到压平截断的原文。 */
    private static String humanArgs(String json) {
        if (json == null || json.isBlank() || json.replaceAll("\\s+", "").equals("{}")) return "";
        com.google.gson.JsonObject o;
        try {
            o = com.google.gson.JsonParser.parseString(json).getAsJsonObject();
        } catch (RuntimeException e) {
            return compactRaw(json);
        }
        List<String> parts = new ArrayList<>();
        try {
            for (String k : new String[]{"item", "item_id", "block", "block_id", "entity", "target",
                    "name", "skill", "structure", "biome", "recipe", "query", "text", "button", "slot"}) {
                if (parts.size() >= 2) break;
                var v = o.get(k);
                if (v != null && v.isJsonPrimitive()) parts.add(stripNs(v.getAsString()));
            }
            for (String k : new String[]{"block_ids", "items"}) {
                if (!parts.isEmpty()) break;
                var v = o.get(k);
                if (v != null && v.isJsonArray() && !v.getAsJsonArray().isEmpty()) {
                    var a = v.getAsJsonArray();
                    StringBuilder b = new StringBuilder();
                    for (int i = 0; i < a.size() && i < 2; i++) {
                        if (i > 0) b.append('、');
                        b.append(stripNs(a.get(i).getAsString()));
                    }
                    if (a.size() > 2) b.append('…');
                    parts.add(b.toString());
                }
            }
            var count = o.get("count");
            if (count != null && count.isJsonPrimitive()) parts.add("×" + count.getAsString());
            if (o.has("x") && o.has("y") && o.has("z")) {
                parts.add("(" + o.get("x").getAsInt() + ", " + o.get("y").getAsInt()
                        + ", " + o.get("z").getAsInt() + ")");
            }
        } catch (RuntimeException ignored) { /* 结构不合预期:能抓多少是多少 */ }
        if (parts.isEmpty()) return compactRaw(json);
        return String.join(" · ", parts.subList(0, Math.min(3, parts.size())));
    }

    private static String stripNs(String s) {
        return s != null && s.startsWith("minecraft:") ? s.substring(10) : s;
    }

    private static String compactRaw(String json) {
        String args = json.replaceAll("\\s+", " ").trim();
        if (args.length() > TOOL_ARG_CHARS) args = args.substring(0, TOOL_ARG_CHARS) + "…";
        return args;
    }

    private static boolean looksFailed(String content) {
        if (content == null) return false;
        String c = content.replaceAll("\\s+", "");
        return c.contains("\"success\":false") || c.startsWith("ERROR") || c.contains("\"error\"");
    }
}
