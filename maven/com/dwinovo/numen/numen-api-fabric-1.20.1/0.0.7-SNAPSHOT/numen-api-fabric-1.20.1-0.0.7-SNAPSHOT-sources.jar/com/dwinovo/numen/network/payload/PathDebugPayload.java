package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.network.NumenPayload;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: one companion's live pathing state for debug overlay
 * rendering. Sent periodically (a few times a second) to owners who toggled
 * debug mode; the client draws it as world-space lines/boxes every frame, so
 * no particle spam is involved. Positions travel as {@code BlockPos#asLong}.
 *
 * <p>Categories: the current path (walked segment onward), the planned next
 * segment, the in-flight search's best partial path, blocks the route will
 * break / place / squeeze through, goal marker boxes, and goal columns
 * (an x/z-only goal rendered as a vertical line; y in the packed long is 0).
 */
public record PathDebugPayload(UUID companionId,
                               List<Long> currentPath, List<Long> nextPath, List<Long> bestPath,
                               List<Long> toBreak, List<Long> toPlace, List<Long> toWalkInto,
                               List<Long> goalBoxes, List<Long> goalColumns)
        implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "path_debug");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(companionId);
        writeLongs(buf, currentPath);
        writeLongs(buf, nextPath);
        writeLongs(buf, bestPath);
        writeLongs(buf, toBreak);
        writeLongs(buf, toPlace);
        writeLongs(buf, toWalkInto);
        writeLongs(buf, goalBoxes);
        writeLongs(buf, goalColumns);
    }

    public static PathDebugPayload read(class_2540 buf) {
        return new PathDebugPayload(buf.method_10790(),
                readLongs(buf), readLongs(buf), readLongs(buf),
                readLongs(buf), readLongs(buf), readLongs(buf),
                readLongs(buf), readLongs(buf));
    }

    private static void writeLongs(class_2540 buf, List<Long> list) {
        buf.method_10804(list.size());
        for (long v : list) {
            buf.writeLong(v);
        }
    }

    private static List<Long> readLongs(class_2540 buf) {
        int n = buf.method_10816();
        List<Long> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(buf.readLong());
        }
        return list;
    }

    /** Client-side handler (client main thread): stash for the frame renderer. */
    public static void handle(PathDebugPayload p) {
        com.dwinovo.numen.client.debug.PathDebugState.accept(p);
    }
}
