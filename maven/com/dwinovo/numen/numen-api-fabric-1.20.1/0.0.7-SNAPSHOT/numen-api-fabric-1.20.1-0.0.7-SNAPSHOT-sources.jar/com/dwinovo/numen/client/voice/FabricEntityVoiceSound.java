package com.dwinovo.numen.client.voice;

import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2960;
import net.minecraft.class_4234;
import net.minecraft.class_4237;
import net.minecraft.class_742;

/**
 * Fabric 侧的同伴 3D 语音:Fabric API 的 sound-api-v1 自带取数重定向
 * ({@code SoundSystemMixin} 已把 {@code SoundEngine.play} 里 vanilla 形状的
 * {@code SoundBufferLibrary.getStream} INVOKE 重定向到接口注入的
 * {@code FabricSoundInstance.getAudioStream})。自己再对同一 INVOKE 上
 * @Redirect 必然与之冲突(先到者改写字节码,后到者 0 目标掀桌),所以
 * 这侧覆写 Fabric API 的钩子返回 {@link #openStream()},零自有 mixin。
 */
public final class FabricEntityVoiceSound extends EntityVoiceSound {

    public FabricEntityVoiceSound(UUID entityUuid, class_742 body, PcmAudio audio, float volume) {
        super(entityUuid, body, audio, volume);
    }

    @Override
    public CompletableFuture<class_4234> getAudioStream(class_4237 loader, class_2960 id,
                                                         boolean repeatInstantly) {
        return openStream();
    }
}
