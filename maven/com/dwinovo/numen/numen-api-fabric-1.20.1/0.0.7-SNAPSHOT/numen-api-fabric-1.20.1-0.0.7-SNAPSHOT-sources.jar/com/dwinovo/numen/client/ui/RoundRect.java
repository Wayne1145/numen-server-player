package com.dwinovo.numen.client.ui;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_332;
import net.minecraft.class_5944;
import org.joml.Matrix4f;
import org.joml.Vector4f;

/**
 * Anti-aliased rounded-rectangle fill via a tiny SDF core shader
 * ({@code assets/numen_api/shaders/core/rendertype_round_rect}). The shader is
 * loader-registered (RegisterShadersEvent / CoreShaderRegistrationCallback) and
 * handed in through {@link #setShader}; while it's absent (load failure, or a
 * pack replaced it with garbage) every call degrades to a plain square fill, so
 * the GUI never breaks — it just loses its corners.
 */
public final class RoundRect {

    private static class_5944 shader;

    private RoundRect() {}

    /** Loader-side registration callback target. */
    public static void setShader(class_5944 s) {
        shader = s;
    }

    /** A bordered card: 1px border colour ring + inset body fill, same corner family. */
    public static void card(class_332 g, int x1, int y1, int x2, int y2, float radius, int fill, int border) {
        fill(g, x1, y1, x2, y2, radius, border);
        fill(g, x1 + 1, y1 + 1, x2 - 1, y2 - 1, Math.max(0f, radius - 1f), fill);
    }

    public static void fill(class_332 g, int x1, int y1, int x2, int y2, float radius, int argb) {
        class_5944 sh = shader;
        radius = Math.min(radius, Math.min(x2 - x1, y2 - y1) / 2f);
        if (sh == null || radius <= 0) {
            g.method_25294(x1, y1, x2, y2, argb);
            return;
        }
        g.method_51452();

        Matrix4f pose = g.method_51448().method_23760().method_23761();
        // u_Rect must be in the same space as the baked vertex positions (pose is translation-only here)
        Vector4f center = pose.transform(new Vector4f((x1 + x2) / 2f, (y1 + y2) / 2f, 0f, 1f));
        sh.method_35785("u_Rect").method_1254(center.x(), center.y(), (x2 - x1) / 2f, (y2 - y1) / 2f);
        sh.method_35785("u_Radius").method_1251(radius);

        float a = (argb >>> 24) / 255f;
        float r = (argb >> 16 & 0xFF) / 255f;
        float gr = (argb >> 8 & 0xFF) / 255f;
        float b = (argb & 0xFF) / 255f;

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(() -> sh);
        // 1.20.1 顶点 API(getBuilder/begin/endVertex/end)——1.21 的 begin(...)/buildOrThrow 尚不存在。
        class_287 bb = class_289.method_1348().method_1349();
        bb.method_1328(class_293.class_5596.field_27382, class_290.field_1576);
        bb.method_22918(pose, x1, y1, 0).method_22915(r, gr, b, a).method_1344();
        bb.method_22918(pose, x1, y2, 0).method_22915(r, gr, b, a).method_1344();
        bb.method_22918(pose, x2, y2, 0).method_22915(r, gr, b, a).method_1344();
        bb.method_22918(pose, x2, y1, 0).method_22915(r, gr, b, a).method_1344();
        class_286.method_43433(bb.method_1326());
        RenderSystem.disableBlend();
    }
}
