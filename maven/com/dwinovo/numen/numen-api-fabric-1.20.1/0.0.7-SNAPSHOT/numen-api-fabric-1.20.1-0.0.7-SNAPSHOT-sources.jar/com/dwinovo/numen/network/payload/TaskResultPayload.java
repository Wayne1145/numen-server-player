package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.agent.tool.ServerToolTransport;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server-to-client payload: result of a previously requested tool execution.
 * Server drains task outboxes each tick and ships completed results back to
 * the owning player; the player's {@code EntityAgentLoop} feeds them into
 * the LLM conversation as {@code role:tool} messages, then triggers the
 * next turn when all pending results are in.
 *
 * <h2>Pairing</h2>
 * {@link #toolCallId} matches the one in the originating {@link ExecuteToolPayload}
 * and, transitively, the LLM's tool_call.id — this is the field that
 * threads request→execution→reply through the network boundary.
 *
 * <h2>Result body</h2>
 * Pre-serialised JSON string ({@link com.dwinovo.numen.task.TaskResult#toJson}).
 * Server-side decisions about field shape live in {@code TaskResult}; the
 * network layer just shuttles bytes.
 */
public record TaskResultPayload(UUID entityUuid,
                                 String toolCallId,
                                 String resultJson) implements NumenPayload {

    public static final int MAX_TOOL_CALL_ID_LENGTH = 128;
    public static final int MAX_RESULT_JSON_LENGTH = 16 * 1024;

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "task_result");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10788(toolCallId, MAX_TOOL_CALL_ID_LENGTH);
        buf.method_10788(resultJson, MAX_RESULT_JSON_LENGTH);
    }

    public static TaskResultPayload read(class_2540 buf) {
        return new TaskResultPayload(buf.method_10790(),
                buf.method_10800(MAX_TOOL_CALL_ID_LENGTH),
                buf.method_10800(MAX_RESULT_JSON_LENGTH));
    }

    /** Client-side handler. Runs on client main thread (network layer arranges that). */
    public static void handle(TaskResultPayload p) {
        Constants.LOG.debug("[numen-net] task_result entity={} tool_call_id={} → {}",
                p.entityUuid(), p.toolCallId(), truncate(p.resultJson(), 200));
        ServerToolTransport.deliver(p.toolCallId(), p.resultJson());
    }

    private static String truncate(String s, int max) {
        if (s == null) return "";
        return s.length() <= max ? s : s.substring(0, max) + "...";
    }
}
