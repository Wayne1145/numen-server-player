package com.dwinovo.numen.network.payload;

import com.dwinovo.numen.Constants;
import com.dwinovo.numen.client.agent.AgentLoopRegistry;
import com.dwinovo.numen.network.NumenPayload;
import java.util.UUID;
import net.minecraft.class_2540;
import net.minecraft.class_2960;

/**
 * Server → Client: an Numen body died for good. The owner's client-side
 * {@link com.dwinovo.numen.client.agent.EntityAgentLoop} must stop — a dead
 * companion has no body to act through, so it must never call the LLM again.
 *
 * <h2>Death is recoverable (not disposed)</h2>
 * The companion respawns at its owner after a delay (see {@link NumenRespawnPayload}), so the loop
 * is SUSPENDED, not disposed. {@code cause} is the vanilla death message for that tool result.
 */
public record NumenDeathPayload(UUID entityUuid, String cause, long respawnDelayMs)
        implements NumenPayload {

    public static final class_2960 ID = new class_2960(Constants.MOD_ID, "numen_death");

    @Override
    public class_2960 id() {
        return ID;
    }

    @Override
    public void write(class_2540 buf) {
        buf.method_10797(entityUuid);
        buf.method_10814(cause);
        buf.method_10791(respawnDelayMs);
    }

    public static NumenDeathPayload read(class_2540 buf) {
        return new NumenDeathPayload(buf.method_10790(), buf.method_19772(), buf.method_10792());
    }

    /** Client-side handler. Runs on the client main thread (network layer arranges that). */
    public static void handle(NumenDeathPayload p) {
        Constants.LOG.info("[numen-net] numen_death entity={} ({}) — suspending loop", p.entityUuid(), p.cause());
        AgentLoopRegistry.get(p.entityUuid()).ifPresent(loop -> loop.onEntityDied(p.cause()));
        // Keep it in the roster (marked dead) so the HUD / rail can show the respawn countdown;
        // it goes live again on NumenRespawnPayload.
        com.dwinovo.numen.client.agent.ClientDeaths.markDead(
                p.entityUuid(), System.currentTimeMillis() + p.respawnDelayMs());
    }
}
