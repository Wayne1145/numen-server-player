package com.dwinovo.numen.client.voice;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2960;
import net.minecraft.class_4234;
import net.minecraft.class_4237;

/**
 * Fabric 侧的试听 2D 播放:与 {@link FabricEntityVoiceSound} 同理,覆写
 * Fabric API sound-api-v1 的 {@code FabricSoundInstance.getAudioStream}
 * 取数钩子,零自有 mixin。
 */
public final class FabricVoicePreviewSound extends VoicePreviewSound {

    public FabricVoicePreviewSound(PcmAudio audio, float volume) {
        super(audio, volume);
    }

    @Override
    public CompletableFuture<class_4234> getAudioStream(class_4237 loader, class_2960 id,
                                                         boolean repeatInstantly) {
        return openStream();
    }
}
