package com.dwinovo.numen.entity;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_18;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_4844;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Persistent index of every companion that exists, keyed by companion UUID.
 * The companion BODY (inventory, position, owner) persists for free as a vanilla
 * player {@code .dat}, but vanilla never enumerates the {@code playerdata/}
 * folder for players that aren't logging in — so without this index we couldn't
 * know which companions to recreate, or who owns them, while they sit dormant.
 *
 * <p>World-saved on the overworld data storage (one file, all owners' companions).
 * The {@code dimension}/{@code pos} are a respawn hint (which level to construct
 * the body in); the {@code .dat} carries the authoritative restored state.
 */
@com.dwinovo.numen.api.Internal
public final class CompanionRegistry extends class_18 {

    /** One companion's catalog entry. {@code diedAt > 0} = dead, awaiting a respawn-at-owner (the death
     *  state is persisted here so it SURVIVES a logout during the respawn window — see Companions).
     *  {@code skinValue}/{@code skinSig} = 借来的正版皮肤(Mojang 签名的 textures 属性),
     *  空串 = 无皮肤,客户端回落原版默认皮肤(按 UUID 哈希抽取)。 */
    public record Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos,
                        String deathCause, long diedAt, String skinValue, String skinSig) {
        /** A live companion (not dead), no borrowed skin. */
        public Entry(String name, UUID owner, class_5321<class_1937> dimension, class_2338 pos) {
            this(name, owner, dimension, pos, "", 0L, "", "");
        }

        /** 刷新落点(休眠/移动时的 respawn 提示),皮肤与死亡状态原样保留。 */
        public Entry movedTo(class_5321<class_1937> dimension, class_2338 pos) {
            return new Entry(name, owner, dimension, pos, deathCause, diedAt, skinValue, skinSig);
        }

        /** 换上 Mojang 签名的皮肤数据(value+signature)。 */
        public Entry withSkin(String value, String sig) {
            return new Entry(name, owner, dimension, pos, deathCause, diedAt,
                    value == null ? "" : value, sig == null ? "" : sig);
        }

        Entry dead(String cause, long at) {
            return new Entry(name, owner, dimension, pos, cause, at, skinValue, skinSig);
        }

        Entry alive() {
            return new Entry(name, owner, dimension, pos, "", 0L, skinValue, skinSig);
        }

        static final Codec<Entry> CODEC = RecordCodecBuilder.create(i -> i.group(
                Codec.STRING.fieldOf("name").forGetter(Entry::name),
                class_4844.field_41525.fieldOf("owner").forGetter(Entry::owner),
                class_5321.method_39154(class_7924.field_41223).fieldOf("dimension").forGetter(Entry::dimension),
                class_2338.field_25064.fieldOf("pos").forGetter(Entry::pos),
                Codec.STRING.optionalFieldOf("deathCause", "").forGetter(Entry::deathCause),
                Codec.LONG.optionalFieldOf("diedAt", 0L).forGetter(Entry::diedAt),
                Codec.STRING.optionalFieldOf("skinValue", "").forGetter(Entry::skinValue),
                Codec.STRING.optionalFieldOf("skinSig", "").forGetter(Entry::skinSig)
        ).apply(i, Entry::new));
    }

    private static final Codec<CompanionRegistry> CODEC =
            Codec.unboundedMap(class_4844.field_41525, Entry.CODEC)
                    .xmap(CompanionRegistry::new, d -> d.entries)
                    .fieldOf("companions").codec();

    // 1.20.1 predates SavedData.Factory and the HolderLookup-aware save/load; register via the
    // classic computeIfAbsent(loadFn, factory, name) and (de)serialise through CODEC ourselves.
    @Override
    public class_2487 method_75(class_2487 tag) {
        CODEC.encodeStart(class_2509.field_11560, this).result()
                .ifPresent(t -> { if (t instanceof class_2487 c) tag.method_10543(c); });
        return tag;
    }

    private static CompanionRegistry load(class_2487 tag) {
        return CODEC.parse(class_2509.field_11560, tag).result().orElseGet(CompanionRegistry::new);
    }

    private final Map<UUID, Entry> entries;

    private CompanionRegistry() {
        this.entries = new HashMap<>();
    }

    private CompanionRegistry(Map<UUID, Entry> entries) {
        this.entries = new HashMap<>(entries);
    }

    public static CompanionRegistry get(MinecraftServer server) {
        return server.method_30002().method_17983()
                .method_17924(CompanionRegistry::load, CompanionRegistry::new, "numen_companions");
    }

    /** Add or update a companion's catalog entry. */
    public void put(UUID companionUuid, Entry entry) {
        entries.put(companionUuid, entry);
        method_80();
    }

    public Entry find(UUID companionUuid) {
        return entries.get(companionUuid);
    }

    public void remove(UUID companionUuid) {
        if (entries.remove(companionUuid) != null) method_80();
    }

    /** Every companion owned by {@code ownerUuid} (UUID + entry). */
    public List<Map.Entry<UUID, Entry>> ownedBy(UUID ownerUuid) {
        List<Map.Entry<UUID, Entry>> out = new ArrayList<>();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            if (e.getValue().owner().equals(ownerUuid)) out.add(e);
        }
        return out;
    }

    /** Every companion currently dead and awaiting respawn (persisted, survives a logout). */
    public List<Map.Entry<UUID, Entry>> pendingDead() {
        List<Map.Entry<UUID, Entry>> out = new ArrayList<>();
        for (Map.Entry<UUID, Entry> e : entries.entrySet()) {
            if (e.getValue().diedAt() > 0L) out.add(e);
        }
        return out;
    }

    /** Mark a companion dead (records the cause + game-time, persisted for the respawn timer). */
    public void markDead(UUID uuid, String cause, long diedAt) {
        Entry e = entries.get(uuid);
        if (e == null) return;
        entries.put(uuid, e.dead(cause, diedAt));
        method_80();
    }

    /** Clear the death state (called when the body is respawned). */
    public void markAlive(UUID uuid) {
        Entry e = entries.get(uuid);
        if (e == null || e.diedAt() == 0L) return;
        entries.put(uuid, e.alive());
        method_80();
    }
}
