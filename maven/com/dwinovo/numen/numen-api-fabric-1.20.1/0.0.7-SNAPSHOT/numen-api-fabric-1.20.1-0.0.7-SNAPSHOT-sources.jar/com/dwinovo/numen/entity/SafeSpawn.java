package com.dwinovo.numen.entity;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3218;
import net.minecraft.class_3481;
import net.minecraft.class_3486;
import net.minecraft.class_5819;

/**
 * Finds a safe landing spot for a companion body near a point (its owner). A raw
 * {@code owner.position()} spawn suffocates the body when the owner is in a tight
 * tunnel / crawling under a low ceiling: the full player hitbox overlaps blocks,
 * takes in-wall damage every tick, dies, and respawns into the same spot — a
 * death loop until the owner happens to move.
 *
 * <p>Search shape: up to 10 random samples in a 7×3×7 box around the anchor
 * (rejecting spots hugging the anchor so the body isn't shoved into a wall by
 * entity pushing in a narrow space), then a deterministic sweep nearest-first
 * that also climbs upward (owner at the bottom of a pit). Every candidate must
 * offer full-block footing that isn't hazardous, feet/head clear of fire, lava
 * and (at head height) any fluid, and room for a standing player hitbox.
 */
@com.dwinovo.numen.api.Internal
final class SafeSpawn {

    private static final int RANDOM_ATTEMPTS = 10;
    private static final int HORIZONTAL_RANGE = 3;
    private static final int UPWARD_SWEEP = 8;
    private static final double HALF_WIDTH = 0.3;
    private static final double HEIGHT = 1.8;

    private SafeSpawn() {}

    /**
     * A safe standing spot near {@code center} (block-bottom-centered), or
     * {@code null} if the whole neighborhood is unusable right now — the caller
     * decides whether to fall back or wait and retry.
     */
    static class_243 findNear(class_3218 level, class_243 center) {
        class_2338 origin = class_2338.method_49638(center);
        class_5819 random = level.method_8409();
        for (int i = 0; i < RANDOM_ATTEMPTS; i++) {
            int dx = random.method_43048(HORIZONTAL_RANGE * 2 + 1) - HORIZONTAL_RANGE;
            int dy = random.method_43048(3) - 1;
            int dz = random.method_43048(HORIZONTAL_RANGE * 2 + 1) - HORIZONTAL_RANGE;
            if (Math.abs(dx) < 2 && Math.abs(dz) < 2) continue;   // not on top of the anchor
            class_2338 pos = origin.method_10069(dx, dy, dz);
            if (isSafe(level, pos)) return class_243.method_24955(pos);
        }
        // Random phase dry — sweep deterministically, closest ring first per layer,
        // climbing from one below the anchor up out of a possible pit.
        for (int dy = -1; dy <= UPWARD_SWEEP; dy++) {
            for (int r = 0; r <= HORIZONTAL_RANGE; r++) {
                for (int dx = -r; dx <= r; dx++) {
                    for (int dz = -r; dz <= r; dz++) {
                        if (Math.max(Math.abs(dx), Math.abs(dz)) != r) continue;
                        class_2338 pos = origin.method_10069(dx, dy, dz);
                        if (isSafe(level, pos)) return class_243.method_24955(pos);
                    }
                }
            }
        }
        return null;
    }

    /**
     * Whether a standing player hitbox fits at this exact (non-grid) point.
     * Fallback check for anchors on non-full-block floors (slabs, carpet) where
     * no grid candidate has sturdy footing: wherever the owner can stand, the
     * body can too.
     */
    static boolean hasStandingRoom(class_3218 level, class_243 pos) {
        return level.method_18026(standingBox(pos.field_1352, pos.field_1351, pos.field_1350));
    }

    private static boolean isSafe(class_3218 level, class_2338 pos) {
        if (!level.method_8621().method_11952(pos)) return false;
        class_2338 belowPos = pos.method_10074();
        class_2680 footing = level.method_8320(belowPos);
        if (!footing.method_26206(level, belowPos, class_2350.field_11036)) return false;
        if (footing.method_27852(class_2246.field_10092) || footing.method_27852(class_2246.field_10029)) return false;
        class_2680 feet = level.method_8320(pos);
        class_2680 head = level.method_8320(pos.method_10084());
        if (feet.method_26164(class_3481.field_21952) || head.method_26164(class_3481.field_21952)) return false;
        if (feet.method_26227().method_15767(class_3486.field_15518)) return false;
        if (!head.method_26227().method_15769()) return false;   // head must be breathable
        return level.method_18026(standingBox(pos.method_10263() + 0.5, pos.method_10264(), pos.method_10260() + 0.5));
    }

    private static class_238 standingBox(double x, double y, double z) {
        return new class_238(x - HALF_WIDTH, y, z - HALF_WIDTH, x + HALF_WIDTH, y + HEIGHT, z + HALF_WIDTH);
    }
}
